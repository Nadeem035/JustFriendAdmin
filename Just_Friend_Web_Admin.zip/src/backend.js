export const API = "http://144.91.80.25:4005/api";
export const IMGAPI = "http://144.91.80.25:4005/";
// export const API = "http://localhost:4000/api";
// export const IMGAPI = "http://localhost:4000/uploads/";
