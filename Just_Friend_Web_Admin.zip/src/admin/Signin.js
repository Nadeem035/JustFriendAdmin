import React, { useState, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import logo from "../assets/img/reactlogo.png";
import { Redirect } from "react-router-dom";
import { postData } from "../services/http.service";
import { authenticate, isAuthenticated } from "../services/auth";
import Constants from "../services/constant";

export default function Signin() {
  const [values, setValues] = useState({
    email: "",
    password: "",
    error: "",
    loading: false,
    didRedirect: false,
    message: "",
  });
  const { email, password, error, loading, didRedirect } = values;

  const handleChange = (name) => (event) => {
    setValues({ ...values, error: false, [name]: event.target.value });
  };
  const onSubmit = (event) => {
    event.preventDefault();
    setValues({ ...values, error: false, loading: true });
    postData(Constants.END_POINT.SIGIN, { email, password })
      .then((response) => {
        console.log(response);
        if (response.error) {
          setValues({ ...values, error: response.message, loading: false });
        } else {
          authenticate(response, () => {
            setValues({
              ...values,
              didRedirect: true,
            });
          });
        }
      })
      .catch((error) => {
        console.log("signin request failed==>", error);
      });
  };

  const performRedirect = () => {
    if (didRedirect) {
      if (isAuthenticated()) {
        return <Redirect to="/admin/dashboard" />;
      } else {
        return <Redirect to="/" />;
      }
    }
  };

  const loadingMessage = () => {
    return (
      loading && (
        <div className="alert alert-info">
          <h5>Loading...</h5>
        </div>
      )
    );
  };

  const errorMessage = () => {
    return (
      <div className="row">
        <div className="col-md-6 offset-sm-3 text-left">
          <div
            className="alert alert-danger"
            style={{ display: error ? "" : "none" }}
          >
            {error}
          </div>
        </div>
      </div>
    );
  };

  const signInForm = () => {
    return (
      <div className="row  ">
        <div className="col-md-12 text-left">
          <form>
            <div className="form-group">
              <label className="text-light">E-Mail</label>
              <input
                value={email}
                onChange={handleChange("email")}
                className="form-control"
                type="email"
                placeholder="Enter Your Email"
              />
            </div>
            <div className="form-group">
              <label className="text-light">Password</label>
              <input
                value={password}
                onChange={handleChange("password")}
                className="form-control"
                type="password"
                placeholder="Enter Your Password"
              />
            </div>
            <button
              onClick={onSubmit}
              className="btn btn-success btn-fill btn-block"
            >
              Sign In
            </button>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div>
      <br />
      <br />
      <div className="col-md-6 col-12 bg-info rounded p-2 mx-2 mx-md-auto ">
        <div className="col-12 d-flex justify-content-center">
          <img src={logo} alt="" width="100px" />
        </div>
        {loadingMessage()}
        {errorMessage()}
        {signInForm()}
        {performRedirect()}
      </div>
    </div>
  );
}
