import React from "react";

export default function Loader() {
  return (
    <div>
      <div className="loader_container">
        <div className="loader"></div>
      </div>
    </div>
  );
}
